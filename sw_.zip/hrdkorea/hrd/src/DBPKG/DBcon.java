package DBPKG;
import java.sql.*;
public class DBcon {
	public static Connection getConnection() throws Exception{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe","ncstest","1234");
				
		return con;
	}
}
