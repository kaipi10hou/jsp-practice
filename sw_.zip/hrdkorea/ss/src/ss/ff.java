package ss;

public class ff {
	public static void main(String args[]){
		System.out.println(99);
		collatz c = new collatz();
		System.out.println("�ٸ�"+c.solution2(626331));
		System.out.println("����ȯ:"+solution(626331));
		
		
	}
	  public static int solution(int num) {
		  String a = "fdasdf";
		  System.out.println(a.length());
		  System.out.println("ffff:"+a.substring(1, 3));
		  
		     long n= (long)num;
			  int answer = 0;
		       while(n!=1){
		        if(n%2==0){
		            n/=2;
		            answer++;
		        }else if(n%2==1){
		            n=n*3+1;
		            answer++;
		            }
		        if(answer>500){
		                 answer=-1;
		                return answer;
		        }
		       }
		        return answer;
		    }
	  
}
class collatz {
	 public int solution2(int num) {
		  long answer = (long)num;
		  for(int i=0; i<500; i++) {
			  if(answer==1) return i;
			  answer=(answer%2==0) ? answer/2 : answer*3+1;
		  }
		  return -1;
	  }
}
